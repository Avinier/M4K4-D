"""Generated A0 datums, mm. Refresh through mass_layout.py --solve."""
AXES = {'roll_y': -1.0583192246049042, 'roll_z': 46.614280733559696, 'pitch_x': -39.022452508038526, 'pitch_z': 45.274531533499186}
